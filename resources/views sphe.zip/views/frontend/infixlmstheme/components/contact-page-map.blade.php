<div>
    <div class="contact_map">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div id="contact-map"></div>
                </div>
            </div>
        </div>
    </div>
</div>
