{{--
<div class="col-md-6 col-lg-4 col-xl-4">
    <div class="single_instractor mb_30">
        <a href="instractor-details.php" class="thumb">
            <img src="img/instractors/1.jpg" alt="">
        </a>
        <div class="instractor_meta">
            <a href="instractor-details.php"><h4>Leonardo Dicaprio</h4></a>
            <span>Exmouth, United Kingdom</span>
        </div>
    </div>
</div>--}}
