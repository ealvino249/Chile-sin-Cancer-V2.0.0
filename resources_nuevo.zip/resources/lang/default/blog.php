<?php

return [
    'Blog' => 'Blog',
    'Blogs' => 'Blogs',
    'List' => 'List',
    'Create' => 'Create',
    'Show' => 'Show',
    'Blog List' => 'Blog List',
    'Title' => 'Title',
    'Slug' => 'Slug',
    'Description' => 'Description',
    'Status' => 'Status',
    'Thumbnail' => 'Thumbnail',
    'Viewed' => 'Viewed',
    'Image' => 'Image',
    'Authored Date' => 'Authored Date',
    'Post By' => 'Post By',
    'SL' => 'SL',
    'Browse Image File' => 'Browse Image File',
    'Publish Date'=>'Publish Date',
    'Blog Categories'=>'Blog Categories',
    'Blog Category List'=>'Blog Category List',
    'Publish Time'=>'Publish Time',
    'Public'=>'Public',
    'Specify'=>'Specify',
    'Target Audience'=>'Target Audience',
    'Org Branch'=>'Org Branch',
    'Authored Time'=>'Authored Time',
    'Blog status is not active'=>'Blog status is not active',
    'Blog is not published yet'=>'Blog is not published yet'
];

