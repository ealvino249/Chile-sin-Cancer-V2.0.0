<?php

return [
    'Saas Branch' => 'Saas Branch',
    'Branches' => 'Branches',
    'Branch' => 'Branch',
    'Domain' => 'Domain',
    'Student' => 'Student',
    'Instructor' => 'Instructor',
    'Admin' => 'Admin',
    'min 3 latter' => 'min 3 latter',
    'Courses in this branch' => 'Courses in this branch',
    'Domain Already Exist.' => 'Domain Already Exist.',
    'You must have active LmsSaas Module.' => 'You must have active LmsSaas Module.',
    'Default User Type' => 'Default User Type',
    'You can not add a branch because you are in main domain. Subdomain Required.' => 'You can not add a branch because you are in main domain. Subdomain Required.',
];
