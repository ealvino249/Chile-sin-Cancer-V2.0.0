<?php

return [
    'Admin Course Revenue List' => 'Admin Course Revenue List',
    'Report' => 'Report',
    'Admin Revenue' => 'Admin Revenue',
    'With Discount' => 'With Discount',
    'Without Discount' => 'Without Discount',
    'Start Date' => 'Start Date',
    'End Date' => 'End Date',
    'Enrolled Student' => 'Enrolled Student',
    'Price' => 'Price',
    'Revenue' => 'Revenue',
    'Discount' => 'Discount',
    'Enrolled Date' => 'Enrolled Date',
    'Purchase ID' => 'Purchase ID',
    'Scorm Report'=>'Scorm Report',
    'XAPI Report'=>'XAPI Report',
];
