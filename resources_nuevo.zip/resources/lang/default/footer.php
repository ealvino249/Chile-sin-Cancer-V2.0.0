<?php

return [
    'Footer' => 'Footer',
    'Footer Settings' => 'Footer Settings',
    'Dashboard' => 'Dashboard',
    'Frontend CMS' => 'Frontend CMS',
    'Copyright Text' => 'Copyright Text',
    'About Text' => 'About Text',
    'Section name' => 'Section name',
    'About Description' => 'About Description',
    'Add New Page' => 'Add New Page',
    'Cancel' => 'Cancel',
    'Widget' => 'Widget',
    'Page Name' => 'Page Name',
    'Edit Link' => 'Edit Link',
    'Widget Title' => 'Widget Title',
    'Add Link' => 'Add Link',
    'Select Page' => 'Select Page',
    'Are you sure' => 'Are you sure',
];
