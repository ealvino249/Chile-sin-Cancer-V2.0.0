<?php
return [
"Newsletter" => "رسالة إخبارية",

"Mailchimp" => "Mailchimp",

"Mailchimp API Setting" => "محددات Mailchimpp API",

"GetResponse" => "جيتاستجابة",

"GetResponse API Setting" => "محددات GetResponse API",

"List Name" => "اسم الكشف",

"Subscribers" => "المشتركين",

"Not Connected" => "غير متصل",

"Connected" => "تم الاتصال",

"API Key" => "مفتاح API",

"Your Mailchimp API key" => "مفتاح Mailychimp API الخاص بك",

"Your GetResponse API key" => "مفتاح Getesالاستجابة API الخاص بك",

"The API key for connecting with your Mailchimp account" => "مفتاح API للاتصال مع حساب Mailchالشمبانزي الخاص بك",

"The API key for connecting with your GetResponse account" => "مفتاح API للاتصال مع حساب GetResponse الخاص بك",

"Get your API key here" => "الحصول على مفتاح API الخاص بك هنا",

"Your Mailchimp Account" => "حساب Mailchالشمبانزي الخاص بك",

"Your GetResponse Account" => "حساب GetResponse",

"No List Found" => "لم يتم ايجاد أي كشف",

"Homepage Method" => "طريقة الصفحة الرئيسية",

"Select Service" => "تحديد خدمة",

"Select List" => "تحديد كشف",

"Local" => "محلية",

"System Subscriber" => "مشترك النظام",

"Select List For Homepage Newsletter Subscription" => "حدد قائمة الاشتراك في النشرة الإخبارية للصفحة الرئيسية",

"Select Service For Homepage" => "تحديد خدمة للصفحة الرئيسية",

"Select Service For Students" => "تحديد خدمة للطلبة",

"Select Service For Instructors" => "تحديد خدمة للمعلمين",

"Select List For Student Subscription After Registration" => "تحديد كشف لاشتراك الطلاب بعد التسجيل",

"Select List For Instructor Subscription After Registration" => "تحديد كشف لمحددات تحديث المعلم بعد التسجيل",

"Subscription List" => "كشف الاشتراك",

"Status" => "الحالة",

"SL" => "L",

"status" => "الحالة",

"id" => "الكود",

"ID" => "الكود",

"Enable" => "اتاحة",

"Setting" => "محددات",

"connected" => "تم الاتصال",

];