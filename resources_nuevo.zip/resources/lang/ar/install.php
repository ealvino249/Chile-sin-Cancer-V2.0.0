<?php
return [
"welcome_description" => "شكرا لاختيار InfixLMS لنظام ادارة التعلم.
     برجاء اتباع الخطوات لاستكمال تركيب InfixLMS !",

"install_with_seed" => "تثبيت مع البذور",

"phone" => "التليفون",

"address" => "العنوان",

"site_title" => "عنوان الموقع",

"Phone" => "التليفون",

"Address" => "العنوان",

];