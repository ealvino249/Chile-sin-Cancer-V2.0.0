<?php
return [
"Admin Course Revenue List" => "كشف العائد للبرنامج التدريبي",

"Report" => "التقرير",

"With Discount" => "بمع الخصم",

"Without Discount" => "بدون خصم",

"Enrolled Student" => "طالب تم تسجيله",

"Enrolled Date" => "تاريخ الاشتراك",

"Purchase ID" => "كود الشراء",

"Start Date" => "تاريخ البدء",

"End Date" => "تاريخ الانتهاء",

"Discount" => "الخصم",

"Revenue" => "العائد",

"Admin Revenue" => "عائد موجه النظام",

"Price" => "السعر",

];