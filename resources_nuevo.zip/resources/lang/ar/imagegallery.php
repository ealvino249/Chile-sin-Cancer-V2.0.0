<?php
return [
"Image Gallery" => "معرض الصور",

"Manage Gallery" => "ادارة الأستوديو",

"Add New Image" => "اضافة صورة جديدة",

"Update Image" => "تعديل الصورة",

"Recommended size 200px x 200px" => "حجم موصى به 200px x 200px",

"Recommended size 370px x 250px" => "حجم مطلوب 370px x 250px",

"Sorry ! Your gallery is empty" => "آسف ، معرضك فارغ",

"Title" => "العنوان",

"Description" => "الوصف",

"Status" => "الحالة",

"Image" => "صورة",

"Add" => "اضافة",

"status" => "الحالة",

"add" => "اضافة",

"description" => "الوصف",

];