<?php
return [
"Role List" => "كشف الوظائف",

"Instructor Role" => "وظيفة المعلم",

"Role has been added Successfully" => "تم اضافة الوظيفة بنجاح",

"Role has been updated Successfully" => "تم تعديل الوظيفة بنجاح",

"Edit Role Info" => "تحرير معلومات الوظيفة",

"Role has been deleted Successfully" => "تم حذف الوظيفة بنجاح",

"Permission" => "التصريح",

"Menu" => "قائمة",

"Sub-Menu" => "قائمة-فرعية",

"assign_permission" => "تخصيص تصريح",

"permission" => "التصريح",

"role_permission" => "تصريح الوظيفة",

"Details" => "التفاصيل",

"Role" => "الوظيفة",

];