<?php
return [
"Sponsor Saved Successfully" => "تم حفظ الاسفسور بنجاح",

"Sponsor Deleted Successfully" => "تم حذف اسراع بنجاح",

"Sponsor Updated Successfully" => "تم تحديث الاسفسور بنجاح",

"Sponsors" => "الجهات الراعية",

"Add New Sponsor" => "اضافة راعي جديد",

"Sponsor List" => "كشف الاسفسور",

"Title" => "العنوان",

"Image" => "صورة",

"Frontend CMS" => "الواجهة الأمامية CMS",

];