<?php
    return [    'reset' => 'Tu contraseña ha sido restablecida.',
    'sent' => 'Hemos enviado por correo electrónico el enlace para restablecer la contraseña.',
    'throttled' => 'Por favor, espere antes de reintentar.',
    'token' => 'Este token de restablecimiento de contraseña no es válido.',
    'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
    'Infix CRM' => 'Infix CRM',
    'Language' => 'Idioma',
        ]
?>