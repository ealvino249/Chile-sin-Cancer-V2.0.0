<?php
    return [    'Role List' => 'Lista de roles',
    'Role' => 'Papel',
    'Instructor Role' => 'Función de instructor',
    'Details' => 'Detalles',
    'Role has been added Successfully' => 'La función ha sido añadida con éxito',
    'Role has been updated Successfully' => 'El rol ha sido actualizado con éxito',
    'Edit Role Info' => 'Editar información del rol',
    'Role has been deleted Successfully' => 'La función ha sido eliminada con éxito',
    'Permission' => 'Permiso',
    'Menu' => 'Menú',
    'Sub-Menu' => 'Submenú',
    'assign_permission' => 'Asignar permiso',
    'role_permission' => 'Permiso de función',
        ]
?>