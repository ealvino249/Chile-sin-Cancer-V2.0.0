<?php
    return [    'Image Gallery' => 'Galería de imágenes',
    'Manage Gallery' => 'Gestionar la galería',
    'Add New Image' => 'Añadir nueva imagen',
    'Update Image' => 'Actualizar imagen',
    'Add' => 'Añadir',
    'Title' => 'Título',
    'Image' => 'Imagen',
    'Recommended size 200px x 200px' => 'Tamaño recomendado 200px x 200px',
    'Recommended size 370px x 250px' => 'Tamaño recomendado 370px x 250px',
    'Description' => 'Descripción',
    'Status' => 'Estado',
    'Sorry ! Your gallery is empty' => '¡Lo sentimos! Su galería está vacía',
        ]
?>