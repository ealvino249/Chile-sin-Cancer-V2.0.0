<?php
    return [    'failed' => 'Estas credenciales no coinciden con nuestros registros.',
    'throttle' => 'Demasiados intentos de inicio de sesión. Por favor, inténtelo de nuevo en :segundos.',
        ]
?>    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
];
