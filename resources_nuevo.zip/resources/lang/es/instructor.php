<?php
    return [    'Instructors' => 'Instructores',
    'Add Instructor' => 'Añadir instructor',
    'About' => 'Acerca de',
    'Date of Birth' => 'Fecha de nacimiento',
    'Payout Lists' => 'Listas de pagos',
    'Payout' => 'Pagos',
        ]
?>