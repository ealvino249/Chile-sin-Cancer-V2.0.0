<?php
    return [    'Blog' => 'Blog',
    'Blogs' => 'Blogs',
    'List' => 'Lista',
    'Create' => 'Crear',
    'Show' => 'Mostrar',
    'Blog List' => 'Lista de blogs',
    'Title' => 'Título',
    'Slug' => 'Babosa',
    'Description' => 'Descripción',
    'Status' => 'Estado',
    'Thumbnail' => 'Miniatura',
    'Viewed' => 'Visto',
    'Image' => 'Imagen',
    'Authored Date' => 'Fecha de autoría',
    'Post By' => 'Publicar por',
    'SL' => 'SL',
    'Browse Image File' => 'Examinar el archivo de imagen',
        ]
?>    'Browse Image File' => 'Browse Image File',
];

