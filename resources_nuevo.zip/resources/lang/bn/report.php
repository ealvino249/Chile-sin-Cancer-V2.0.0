<?php

return [
    'Admin Course Revenue List' => 'অ্যাডমিন কোর্স রাজস্ব তালিকা',
    'Report' => 'রিপোর্ট',
    'Admin Revenue' => 'প্রশাসন রাজস্ব',
    'With Discount' => 'ছাড় সহ',
    'Without Discount' => 'ছাড় ছাড়াই',
    'Start Date' => 'শুরুর তারিখ',
    'End Date' => 'শেষ তারিখ',
    'Enrolled Student' => 'তালিকাভুক্ত ছাত্র',
    'Price' => 'দাম',
    'Revenue' => 'রাজস্ব',
    'Discount' => 'ছাড়',
    'Enrolled Date' => 'নিবন্ধিত তারিখ',
];
