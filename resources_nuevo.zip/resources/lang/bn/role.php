<?php

return [
	'Role List' => 'ভূমিকা তালিকা',
	'Role' => 'ভূমিকা',
    'Instructor Role' => 'প্রশিক্ষকের ভূমিকা',
	'Details' => 'বিশদ',
	'Role has been added Successfully' => 'ভূমিকা সফলভাবে যোগ করা হয়েছে',
	'Role has been updated Successfully' => 'ভূমিকা সফলভাবে আপডেট করা হয়েছে',
	'Edit Role Info' => 'ভূমিকা তথ্য সম্পাদনা করুন',
	'Role has been deleted Successfully' => 'ভূমিকা সফলভাবে মোছা হয়েছে',
	'Permission' => 'অনুমতি',
	'Menu' => 'তালিকা',
	'Sub-Menu' => 'সাব মেনু',
	'assign_permission' => 'অনুমতি বরাদ্দ করুন',
	'role_permission' => 'ভূমিকা অনুমতি',
];
