<?php

return [
	'Image Gallery' => 'ছবির গ্যালারি',
	'Manage Gallery' => 'গ্যালারী পরিচালনা করুন',
	'Add New Image' => 'নতুন চিত্র যুক্ত করুন',
	'Update Image' => 'চিত্র আপডেট করুন',
	'Add' => 'অ্যাড',
	'Title' => 'শিরোনাম',
	'Image' => 'চিত্র',
	'Recommended size 200px x 200px' => 'প্রস্তাবিত আকার 200px x 200px',
	'Recommended size 370px x 250px' => 'প্রস্তাবিত আকার 370px x 250px',
	'Description' => 'বর্ণনা',
	'Status' => 'স্থিতি',
	'Sorry ! Your gallery is empty' => 'দুঃখিত! আপনার গ্যালারী খালি',
];
