<?php

return [
	'Instructors' => 'প্রশিক্ষক',
	'Add Instructor' => 'প্রশিক্ষক যুক্ত করুন',
	'About' => 'সম্পর্কিত',
	'Date of Birth' => 'জন্ম তারিখ',
	'Payout Lists' => 'অর্থ প্রদানের তালিকা',
	'Payout' => 'পরিশোধ',
];
