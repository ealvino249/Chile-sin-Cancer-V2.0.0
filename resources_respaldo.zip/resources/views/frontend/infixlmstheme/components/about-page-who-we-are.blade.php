<div>
    <div class="who_we_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="who_we_info">
                        <div class="info_left">
                            <span>{{__('frontendmanage.Who We Are')}}</span>
                            <p>{{$who_we_are}}</p>
                        </div>
                        <div class="info_right">
                            <p>{{$banner_title}}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
