<?php
return [
    "welcome_description" => "Thank you for choosing InfixLMS for learning management system.
     Please follow the steps to complete InfixLMS installation!",
    'install_with_seed'=>'Install with demo data',
    'phone'=>'Phone',
    'address'=>'Address',
    'site_title'=>'Site Title',

];
