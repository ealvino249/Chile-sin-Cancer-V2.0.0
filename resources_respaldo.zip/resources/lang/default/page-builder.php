<?php

return [
    'Page Builder' => 'Page Builder',
    'Pages' => 'Pages',
    'Page' => 'Page',
    'Add New' => 'Add New',
    'SL' => 'SL',
    'Title' => 'Title',
    'Slug' => 'Slug',
    'Status' => 'Status',
    'Body' => 'Body',
    'Create' => 'Create',
    'Create Page' => 'Create Page',
    'Update Page' => 'Update Page',
    'Design' => 'Design',
];
