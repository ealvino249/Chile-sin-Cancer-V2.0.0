<?php

return [
    'Forum Page Title' => 'Forum Page Title',
    'Forum Page Sub Title' => 'Forum Page Sub Title',
    'Forum Page Banner' => 'Forum Page Banner',
    'Assignment' => 'Assignment',
    'Forum' => 'Forum',
];

