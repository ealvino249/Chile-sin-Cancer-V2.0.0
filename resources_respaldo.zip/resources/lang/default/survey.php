<?php

return [
    'Survey' => 'Survey',
    'Answer Set' => 'Answer Set',
    'Answer' => 'Answer',
    'Participation' => 'Participation',
    'Participants' => 'Participants',
    'My Survey' => 'My Survey',
    'Anonymous'=>'Anonymous'
];
