<?php

return [
    'Image Gallery' => 'Image Gallery',
    'Manage Gallery' => 'Manage Gallery',
    'Add New Image' => 'Add New Image',
    'Update Image' => 'Update Image',
    'Add' => 'Add',
    'Title' => 'Title',
    'Image' => 'Image',
    'Recommended size 200px x 200px' => 'Recommended size 200px x 200px',
    'Recommended size 370px x 250px' => 'Recommended size 370px x 250px',
    'Description' => 'Description',
    'Status' => 'Status',
    'Sorry ! Your gallery is empty' => 'Sorry ! Your gallery is empty',
];
?>
