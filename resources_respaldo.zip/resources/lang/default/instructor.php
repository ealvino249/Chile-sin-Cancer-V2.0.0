<?php

return [
    'Instructors' => 'Instructors',
    'Add Instructor' => 'Add Instructor',
    'About' => 'About',
    'Date of Birth' => 'Date of Birth',
    'Payout Lists' => 'Payout Lists',
    'Payout' => 'Payout',
    'Instructor' => 'Instructor'
];
