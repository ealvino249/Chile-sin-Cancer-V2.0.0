<?php
return [
"Footer" => "نص الطرف",

"Footer Settings" => "محددات نص الطرف",

"Frontend CMS" => "الواجهة الأمامية CMS",

"Copyright Text" => "نص حقوق النشر",

"About Text" => "نبذة عن النص",

"Section name" => "اسم القسم",

"About Description" => "نبذة عن الوصف",

"Add New Page" => "اضافة صفحة جديدة",

"Widget" => "عنصر واجهة التعامل",

"Page Name" => "اسم الصفحة",

"Edit Link" => "تحرير الوصلة",

"Widget Title" => "عنوان عنصر واجهة التعامل",

"Add Link" => "اضافة وصلة",

"Select Page" => "تحديد صفحة",

"Are you sure" => "هل أنت متأكد ؟",

"Cancel" => "الغاء",

"Dashboard" => "استعراض بياني",

];