<?php
return [
"Class Setting" => "محددات الفئة",

"Class List" => "كشف الفئة",

"Create Class" => "تكوين فئة",

"Fees" => "الرسوم",

"Add Class" => "اضافة فئة",

"Single Class" => "فئة مفردة",

"Continuous Class" => "فئة مستمرة",

"BBB" => "BBB",

"in Minute" => "في الدقيقة",

"Setup" => "اعداد الفئة الظاهرية",

"Big Blue Button" => "زر أزرق كبير",

"Zoom" => "تكبير",

"Default Class" => "الفئة المفترضة",

"This class is free" => "هذه الفئة مجانية",

"Classes are available" => "الفئات متاحة",

"Title" => "العنوان",

"Browse Image File" => "تصفح ملف الصورة",

"Date" => "التاريخ",

"Browse Image file" => "تصفح ملف الصورة",

"update" => "تعديل",

"time" => "الوقت",

"Free" => "مجانى",

"Details" => "التفاصيل",

"Update" => "تعديل",

"Live" => "مباشر",

"Type" => "النوع",

"Language" => "اللغة",

"Category" => "الفئة",

"Sub Category" => "فئة فرعية",

"date" => "تاريخ",

"Start Date" => "تاريخ البدء",

"End Date" => "تاريخ الانتهاء",

"Duration" => "المدة",

"Live Classes" => "الفئات الحية",

"Time" => "الوقت",

"Classes" => "الفئات",

"Class" => "فئة",

"type" => "النوع",

"Host" => "النظام الرئيسي",

];