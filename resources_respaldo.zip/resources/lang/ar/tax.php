<?php
return [
"TAX" => "الضريبة",

"TAX Setting" => "محددات TAX",

"Apply TAX" => "تطبيق TAX",

"Percentage" => "النسبة المئوية",

"Tax" => "الضريبة",

];