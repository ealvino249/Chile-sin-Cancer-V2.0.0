<?php
return [
"Instructor Payment" => "دفع المعلم",

"Rejected" => "مرفوض",

"Next Payout" => "الدفع التالي",

"You Currently Have" => "لديك حاليا",

"in earnings for next months payout" => "الدخل المربح للأشهر المقبلة الدافعلي",

"Payout Account" => "حساب الدفع",

"Set Account" => "تحديد حساب",

"Payout Email" => "البريد الإلكتروني للدفع",

"Set Payout" => "تعيين الدفع",

"Payout Email Saved Successfully" => "تم حفظ البريد الإلكتروني الخاص بالدفع بنجاح ",

"Payment Status" => "حالة السداد",

"Payment Request" => "طلب السداد",

"Are you Sure, You want to request for payment?" => "هل أنت متأكد ، هل تريد طلب الدفع ؟",

"Confirm" => "تأكيد",

"Are you Sure, You want to mark as payment?" => "هل أنت متأكد ، تريد مارك كدفع ؟",

"Issue Date" => "تاريخ الاصدار",

"Waiting" => "انتظار",

"Instructor" => "المعلم",

"method" => "الطريقة",

"Amount" => "المبلغ",

"Method" => "الطريقة",

"Request Date" => "تاريخ الطلب",

"Approved" => "الوظائف المعتمدة",

"Invoice Date" => "تاريخ الفاتورة",

];