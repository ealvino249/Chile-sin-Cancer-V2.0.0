<?php
return [
"Communication" => "الاتصالات",

"Questions & Answer" => "أسئلة & اجابة",

"Private Messages" => "رسائل خاصة",

"Message List" => "كشف الرسالة",

"Write your message" => "اكتب رسالتك",

"Search content here" => "بحث المحتويات هنا",

"Short Code" => "الكود القصير",

"Field Name" => "اسم المجال",

"Subscriptions" => "الاشتراكات",

"Send Message" => "ارسال رسالة",

"Compose Message" => "تكوين رسالة",

"Your referral link" => "وصلة الإحالة الخاصة بك",

"Copy Link" => "نسخ وصلة",

"Share the referral link with your friends." => "مشاركة وصلة الإحالة مع أصدقائك.",

"Your referral list" => "كشف الإحالة الخاص بك",

"Let's say Hi" => "دعني أقول مرحبا",

"Send Email" => "ارسال بريد الكتروني",

];