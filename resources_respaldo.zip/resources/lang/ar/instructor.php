<?php
return [
"Instructors" => "المعلمون",

"Add Instructor" => "اضافة معلم",

"Payout Lists" => "كشوف المرتبات",

"Payout" => "الدفع",

"About" => "نبذة عن",

"Date of Birth" => "تاريخ الميلاد",

];