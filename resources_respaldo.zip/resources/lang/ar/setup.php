<?php
return [
"Division" => "الشعبة",

"District" => "المقاطعة",

"Upazila" => "أوبازيلا",

"Upazila List" => "قائمة Upazila",

"Bangla Name" => "اسم البنغالية",

"Edit Info Upazila" => "تحرير المعلومات Upazila",

"Division List" => "كشف القسم",

"Edit Info Division" => "تحرير قسم المعلومات",

"District List" => "كشف المناطق",

"Upazila has been added Successfully" => "تم اضافة Upzzila بنجاح",

"Upazila has been updated Successfully" => "تم تعديل Upzzila بنجاح",

"Upazila has been deleted Successfully" => "تم حذف Upzzila بنجاح",

"Division has been added Successfully" => "تم اضافة القسم بنجاح",

"Division has been updated Successfully" => "تم تعديل القسم بنجاح",

"Division has been deleted Successfully" => "تم حذف القسم بنجاح",

"District has been added Successfully" => "تم اضافة المقاطعة بنجاح",

"District has been updated Successfully" => "تم تعديل المقاطعة بنجاح",

"District has been deleted Successfully" => "تم حذف المنطقة بنجاح",

"Tax has been deleted Successfully" => "تم حذف الضريبة بنجاح",

"Tax" => "الضريبة",

"Tax List" => "كشف الضرائب",

"Rate" => "المعدل",

"Edit Tax InFo" => "تحرير المعلومات الضريبية",

"Status" => "الحالة",

"status" => "الحالة",

];