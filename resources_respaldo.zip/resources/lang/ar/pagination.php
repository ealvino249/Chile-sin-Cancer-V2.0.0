<?php
return [
"previous" => "سابق",

"next" => "التالي ;",

"Next" => "تالي",

"Previous" => "سابق",

];