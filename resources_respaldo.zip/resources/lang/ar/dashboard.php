<?php
return [
"Subjects" => "موضوعات",

"Logout" => "انهاء الاتصال",

"Status Overview of Topics" => "نبذة عن الحالة للمواضيع",

"Overview of Topics" => "عرض عام للموضوعات",

"Number of Subjects" => "عدد الموضوعات",

"Enrolled" => "تم التسجيل",

"Number of Enrolled" => "عدد المسجلة",

"Enrolled Amount" => "المبلغ الذي تم تسجيله",

"Total Enrolled Amount" => "اجمالي المبلغ الذي تم تسجيله",

"Enrolled Today" => "تم تسجيله اليوم",

"Total Enrolled Today" => "اجمالي ما تم تسجيله اليوم",

"This Month" => "هذا الشهر",

"Total Enrolled This Month" => "اجمالي ما تم تسجيله هذا الشهر",

"Monthly Income Stats for" => "حالة الدخل الشهرية ل ـ",

"Payment Statistics for" => "احصائيات السداد ل ـ",

"Recent Enrolls" => "القوائم الحديثة",

"Daily Wise Enroll Status for" => "حالة تسجيل Wise Enroll بالنسبة الى",

"Monthly income status" => "حالة الدخل الشهري",

"No Results Found" => "لم يتم ايجاد نتائج",

"Completed" => "أنجز",

"Pending" => "معلق",

"Courses" => "البرامج التدريبية",

"Quizzes" => "الإختبارات",

"active" => "فعال",

"Dashboard" => "استعراض بياني",

"Active" => "فعال",

"Setting" => "محددات",

"Classes" => "الفئات",

"courses" => "البرامج التدريبية",

];