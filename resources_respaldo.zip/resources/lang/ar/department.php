<?php
return [
"Department" => "الادارة",

];