<?php
return [
"Student" => "طالب",

"Successfully" => "نجاح",

"Deleted" => "محذوف",

"Image size is too large" => "حجم الصورة كبير جدا",

"Are you sure want to" => "هل أنت متأكد من أنك تريد",

"Cart" => "عربة",

"Oops" => "أوبس",

"Message" => "الرسالة",

"Activated" => "تم تشغيلها",

"Operation Failed" => "فشل في العملية",

"Account was Created successfully, please Check you Email" => "تم تكوين الحساب بنجاح ، برجاء تحديد بريد الكتروني لك",

"Deactivated" => "الغاء تشغيل",

"Oops, Something Went Wrong" => "أوبس ، شيء ما ذهب خطأ",

"Added" => "تمت الاضافة",

"examinations" => "الامتحانات",

"dashboard" => "استعراض بياني",

"online_exam" => "الامتحان عبر الإنترنت",

"marking" => "الوسم",

"subject" => "الموضوع",

"exam" => "الخروج",

"class_sec" => "فئة ث",

"Yes" => "نعم.",

"Course" => "بالطبع",

"yes" => "نعم.",

"Delete" => "حذف",

"Remove" => "ازالة",

"Cancel" => "الغاء",

"Dashboard" => "استعراض بياني",

"Enable" => "اتاحة",

"Disable" => "الغاء اتاحة",

"Operation failed" => "فشل في العملية",

"message" => "الرسالة",

"delete" => "حذف",

"remove" => "ازالة",

"student" => "طالب",

];