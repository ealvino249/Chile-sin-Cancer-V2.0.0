<?php
return [
"Blog" => "المدونة",

"Blogs" => "المدونات",

"List" => "كشف",

"Create" => "تكوين",

"Show" => "عرض",

"Blog List" => "كشف المدونات",

"Title" => "العنوان",

"Slug" => "سلق",

"Description" => "الوصف",

"Status" => "الحالة",

"Thumbnail" => "صورة مصغرة",

"Viewed" => "تمت المشاهدة",

"Image" => "صورة",

"Authored Date" => "تاريخ التصميم",

"Post By" => "ترحيل بواسطة",

"SL" => "SL",

"Browse Image File" => "تصفح ملف الصورة",

"Browse Image file" => "تصفح ملف الصورة",

"status" => "الحالة",

"create" => "تكوين",

];