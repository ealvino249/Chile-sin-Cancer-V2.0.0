<?php

return [
    'Footer' => 'পাদচরণ',
    'Footer Settings' => 'পাদদেশ সেটিংস',
    'Dashboard' => 'ড্যাশবোর্ড',
    'Frontend CMS' => 'সামনের সিএমএস',
    'Copyright Text' => 'কপিরাইট পাঠ্য',
    'About Text' => 'পাঠ্য সম্পর্কে',
    'Section name' => 'বিভাগের নাম',
    'About Description' => 'বর্ণনা সম্পর্কে',
    'Add New Page' => 'নতুন পৃষ্ঠা যুক্ত করুন',
    'Cancel' => 'বাতিল',
    'Widget' => 'উইজেট',
    'Page Name' => 'পৃষ্ঠার নাম',
    'Edit Link' => 'লিঙ্ক সম্পাদনা করুন',
    'Widget Title' => 'উইজেটের শিরোনাম',
    'Add Link' => 'লিঙ্ক যুক্ত করুন',
    'Select Page' => 'পৃষ্ঠা নির্বাচন করুন',
    'Are you sure' => 'তুমি কি নিশ্চিত',
];
