<?php

return [
    'Blog' => 'ব্লগ',
    'Blogs' => 'ব্লগ',
    'List' => 'তালিকা',
    'Create' => 'সৃষ্টি',
    'Show' => 'দেখান',
    'Blog List' => 'ব্লগ তালিকা',
    'Title' => 'শিরোনাম',
    'Slug' => 'স্লাগ',
    'Description' => 'বর্ণনা',
    'Status' => 'স্থিতি',
    'Thumbnail' => 'থাম্বনেইল',
    'Viewed' => 'দেখা হয়েছে',
    'Image' => 'চিত্র',
    'Authored Date' => 'রচনা তারিখ',
    'Post By' => 'পোস্ট দ্বারা',
    'SL' => 'এসএল',
    'Browse Image File' => 'চিত্র ফাইল ব্রাউজ করুন',
];

