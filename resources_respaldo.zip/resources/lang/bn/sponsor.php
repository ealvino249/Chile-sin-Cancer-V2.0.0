<?php
return [
    'Sponsor Saved Successfully' => 'স্পনসর সাফল্যের সাথে সংরক্ষিত হয়েছে',
    'Sponsor Deleted Successfully' => 'স্পনসর সফলভাবে মোছা হয়েছে',
    'Sponsor Updated Successfully' => 'স্পনসর সফলভাবে আপডেট হয়েছে',
    'Sponsors' => 'স্পনসর',
    'Add New Sponsor' => 'নতুন স্পনসর যুক্ত করুন',
    'Image' => 'চিত্র',
    'Title' => 'শিরোনাম',
    'Sponsor List' => 'স্পনসর তালিকা',
    'Frontend CMS' => 'সামনের সিএমএস',
];
