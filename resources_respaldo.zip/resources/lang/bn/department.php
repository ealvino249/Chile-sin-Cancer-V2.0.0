<?php

return [
	'Department' => 'বিভাগ',
];
