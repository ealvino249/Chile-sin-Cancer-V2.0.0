<?php
    return [    'Admin Course Revenue List' => 'Lista de ingresos del curso de administración',
    'Report' => 'Informe',
    'Admin Revenue' => 'Ingresos administrativos',
    'With Discount' => 'Con descuento',
    'Without Discount' => 'Sin descuento',
    'Start Date' => 'Fecha de inicio',
    'End Date' => 'Fecha de finalización',
    'Enrolled Student' => 'Estudiante matriculado',
    'Price' => 'Precio',
    'Revenue' => 'Ingresos',
    'Discount' => 'Descuento',
    'Enrolled Date' => 'Fecha de inscripción',
        ]
?>