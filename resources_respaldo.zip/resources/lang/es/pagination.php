<?php
    return [    'previous' => 'Anteriormente',
    'next' => 'Siguiente',
        ]
?>