<?php
    return [    'Department' => 'Departamento',
        ]
?>