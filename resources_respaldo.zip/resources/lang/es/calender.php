<?php return array (
  'days' => 
  array (
    0 => 'Domingo',
    1 => 'Lunes',
    2 => 'Martes',
    3 => 'Miércoles',
    4 => 'Jueves',
    5 => 'Viernes',
    6 => 'Sábado',
  ),
  'daysShort' => 
  array (
    0 => 'Dom',
    1 => 'Lun',
    2 => 'Mar',
    3 => 'Mie',
    4 => 'Jue',
    5 => 'Vie',
    6 => 'Sab',
  ),
  'daysMin' => 
  array (
    0 => 'Do',
    1 => 'Lu',
    2 => 'Ma',
    3 => 'Mie',
    4 => 'Ju',
    5 => 'Vi',
    6 => 'Sa',
  ),
  'months' => 
  array (
    0 => 'Enero',
    1 => 'Febrero',
    2 => 'Marzo',
    3 => 'Abril',
    4 => 'Mayo',
    5 => 'Junio',
    6 => 'Julio',
    7 => 'Agosto',
    8 => 'Septiembre',
    9 => 'Octubre',
    10 => 'Noviembre',
    11 => 'Diciembre',
  ),
  'monthsShort' => 
  array (
    0 => 'Ene',
    1 => 'Feb',
    2 => 'Mar',
    3 => 'Abr',
    4 => 'May',
    5 => 'Jun',
    6 => 'Jul',
    7 => 'Ago',
    8 => 'Sep',
    9 => 'Oct',
    10 => 'Nov',
    11 => 'Dic',
  ),
  'today' => 'Hoy',
  'clear' => 'Limpiar',
);