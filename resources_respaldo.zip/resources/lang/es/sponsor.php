<?php
    return [    'Sponsor Saved Successfully' => 'Patrocinador salvado con éxito',
    'Sponsor Deleted Successfully' => 'Patrocinador eliminado con éxito',
    'Sponsor Updated Successfully' => 'Patrocinador actualizado con éxito',
    'Sponsors' => 'Patrocinadores',
    'Add New Sponsor' => 'Añadir nuevo patrocinador',
    'Image' => 'Imagen',
    'Title' => 'Título',
    'Sponsor List' => 'Lista de patrocinadores',
    'Frontend CMS' => 'CMS Frontend',
        ]
?>